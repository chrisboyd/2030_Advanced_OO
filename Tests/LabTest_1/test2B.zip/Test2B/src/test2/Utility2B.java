package test2;


public class Utility2B {
	
	
}
