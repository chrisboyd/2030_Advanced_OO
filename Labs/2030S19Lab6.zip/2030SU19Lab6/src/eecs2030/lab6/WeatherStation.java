package eecs2030.lab6;

import java.util.ArrayList;
import java.util.List;

/**
 * A weather station contains sets of weather sensors to measure various weather
 * parameters and publishes the readings to a list of subscribed weather
 * observers.
 * 
 * The weather station pulls the readings from the sensors. Usually there is a
 * set of redundant sensors for each weather parameter such as temperature and
 * pressure. The value reported by the weather station is the average consensus
 * of the readings, i.e. the average of the available measurements. In case any
 * sensor fails, its reading is eliminated from the average and this sensor will
 * be fixed. The weather station notifies the subscribed observers for any
 * updates in the weather parameters.
 * 
 */
public class WeatherStation {

	/*
	 * Your Task: Declare an attribute for the list of subscribed weather observers.
	 */

	/*
	 * Your Task: Declare attributes for the lists of weather sensors.
	 */

	/**
	 * Initialize a new weather station with no sensors installed.
	 * 
	 */
	public WeatherStation() {
		/* Your Task */
	}

	/**
	 * Subscribe the input weather observer o as one of the observers of the current
	 * weather station.
	 * 
	 * @param o
	 *            a weather observer
	 */
	public void subscribe(WeatherObserver o) {
		/* Your Task */
	}

	/**
	 * Unsubscribe the input weather observer o from the list of observers of the
	 * current weather station. Assume that the input o is an already-subscribed
	 * observer.
	 * 
	 * @param o
	 *            a weather observer
	 */
	public void unsubscribe(WeatherObserver o) {
		/* Your Task */
	}

	/**
	 * Get the list of subscribed weather observers.
	 * 
	 * @return an array of subscribed weather observers.
	 */
	public WeatherObserver[] getObservers() {
		/* Your Task */
		return null;
	}

	/**
	 * Publish the latest readings of weather data to all subscribed observers. That
	 * is, perform an update on each subscribed observer.
	 */
	public void publish() {
		/* Your Task */
	}

	/**
	 * Adds temperature sensor to the corresponding sensor list
	 * 
	 * @param ts
	 *            temperature sensor to be added
	 */
	public void addTempSensor(TemperatureSensor ts) {
		/* Your Task */
	}

	/**
	 * Adds pressure sensor to the corresponding sensor list
	 * 
	 * @param ps
	 *            pressure sensor to be added
	 */
	public void addPressSensor(PressureSensor ps) {
		/* Your Task */
	}

	/**
	 * Removes the temperature sensor from the corresponding sensor list
	 * 
	 * @param ts
	 *            temperature sensor to be removed
	 */
	public void removeTempSensor(TemperatureSensor ts) {
		/* Your Task */
	}

	/**
	 * Removes the pressure sensor from the corresponding sensor list
	 * 
	 * @param ps
	 *            pressure sensor to be removed
	 */
	public void removePressSensor(PressureSensor ps) {
		/* Your Task */
	}

	/**
	 * Get the consensus of temperature measurements.
	 * 
	 * @return latest temperature measure
	 */
	public double getTemperature() {
		/* Your Task */
		return 0;
	}

	/**
	 * Get the consensus of pressure measurements.
	 * 
	 * @return latest pressure measure
	 */
	public double getPressure() {
		/* Your Task */
		return 0;
	}
}