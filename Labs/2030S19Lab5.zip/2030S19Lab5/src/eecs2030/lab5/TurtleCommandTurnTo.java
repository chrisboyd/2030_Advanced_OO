package eecs2030.lab5;

/**
 * A command corresponding to a turtle executing the method
 * {@code turnTo(angle)}.
 *
 */
public class TurtleCommandTurnTo extends TurtleCommand {

	private double angle;
	
	/**
	 * Initialize this command so that this command is associated with
	 * the specified turtle executing a {@code turnTo(angle)}
	 * command.
	 * 
	 * @param turtle the turtle that is associated with this command
	 * @param angle the angle of the turnTo command
	 */
	public TurtleCommandTurnTo(Turtle turtle, double angle) {
		
	}
	
	/**
	 * Returns the angle associated with this command.
	 * 
	 * @return the angle associated with this command
	 */
	public double getAngle() {
		
	}

	/**
	 * Runs the method {@code turnTo(angle)} using the turtle associated
	 * with this command.
	 */
	@Override
	public void execute() {
		
	}

	/**
	 * Runs the method {@code turnTo(angle)} using the specified turtle.
	 */
	@Override
	public void execute(Turtle t) {
		
	}

}
